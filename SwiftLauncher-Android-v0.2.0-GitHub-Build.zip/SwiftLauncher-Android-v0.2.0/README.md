# Swift Launcher Android v0.2.0

Android launcher preview: Kotlin UI + native Rust shared library.

## Targets
- Android 9+ (API 28 minimum)
- 32-bit ARM: `armeabi-v7a`
- 64-bit ARM: `arm64-v8a`
- English interface

## Build the test APK with GitHub Actions
1. Create a GitHub repository named `SwiftLauncher`.
2. Extract this ZIP and upload its **contents** to the repository root (not the ZIP itself).
3. Open the repository's **Actions** tab.
4. Select **Build Swift Launcher Android APK** and press **Run workflow**.
5. Wait for a successful run, open it, and download artifact `SwiftLauncher-Android-APK-armv7-arm64`.
6. Extract the artifact to get `app-debug.apk`, then install it on your phone.

This is a debug APK for testing, not a Play Store release. One APK contains both requested ABIs.

## Honest status
The app shows the Swift Launcher interface and checks that its native Rust library loads. The Play button is a placeholder. This is **not yet a playable Minecraft replacement**. Rendering, world simulation, blocks, items, entities, saves, networking, and version-specific compatibility are not implemented. The version picker is illustrative only and does not download or launch versions.

## Size
The 100–200 MiB limit is the launcher installer ceiling. Game assets and versions are not bundled. Measure the final APK after the workflow completes.

Swift Launcher is independent and unofficial; it is not affiliated with Mojang or Microsoft.
