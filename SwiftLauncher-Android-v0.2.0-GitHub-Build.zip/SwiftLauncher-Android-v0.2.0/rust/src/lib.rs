use jni::objects::{JObject, JString};
use jni::sys::jstring;
use jni::JNIEnv;

// Native Rust bootstrap only; Minecraft gameplay is not implemented yet.
#[no_mangle]
pub extern "system" fn Java_dev_swiftlauncher_app_MainActivity_nativeEngineStatus(
    mut env: JNIEnv, _this: JObject
) -> jstring {
    let msg = "Rust native library loaded; game engine is under development";
    let output: JString = env.new_string(msg).expect("JNI string allocation failed");
    output.into_raw()
}
