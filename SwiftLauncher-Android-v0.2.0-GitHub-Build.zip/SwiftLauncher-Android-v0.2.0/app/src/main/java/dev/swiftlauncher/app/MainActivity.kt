package dev.swiftlauncher.app

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.widget.*

class MainActivity : Activity() {
    private external fun nativeEngineStatus(): String
    companion object { init { System.loadLibrary("swift_engine") } }

    private val versions = listOf("Classic (archive)", "Indev (archive)", "Infdev (archive)", "Alpha (archive)", "Beta (archive)", "1.0", "1.21.1", "26.3", "Latest snapshot (placeholder)")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(12, 20, 27)
        window.navigationBarColor = Color.rgb(12, 20, 27)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 30, 24, 24)
            setBackgroundColor(Color.rgb(9, 14, 19))
        }
        root.addView(TextView(this).apply {
            text = "SWIFT LAUNCHER"; textSize = 27f
            setTextColor(Color.rgb(76, 225, 145)); typeface = Typeface.DEFAULT_BOLD
        })
        root.addView(TextView(this).apply {
            text = "A Rust-powered game project"; textSize = 15f
            setTextColor(Color.LTGRAY); setPadding(0, 8, 0, 24)
        })
        root.addView(TextView(this).apply {
            text = "SELECT VERSION"; textSize = 13f; setTextColor(Color.rgb(76, 225, 145))
        })
        root.addView(Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, versions)
        })
        val status = TextView(this).apply {
            textSize = 14f; setTextColor(Color.LTGRAY); setPadding(0, 20, 0, 12)
        }
        root.addView(Button(this).apply {
            text = "PLAY"; isAllCaps = false
            setOnClickListener { status.text = "The native Rust game engine is not implemented yet. This is an early launcher preview." }
        })
        root.addView(status)
        status.text = try { "Native engine: ${nativeEngineStatus()}" }
        catch (e: UnsatisfiedLinkError) { "Native engine library could not be loaded." }
        root.addView(TextView(this).apply {
            text = "Android 9+ • armeabi-v7a • arm64-v8a\nEnglish interface • Game data stored separately\n\nStarter catalogue only; it does not yet download or run versions."
            textSize = 13f; setTextColor(Color.rgb(175, 188, 195))
        })
        root.addView(TextView(this).apply {
            text = "Swift Launcher v0.2.0 • Development preview"; textSize = 12f
            setTextColor(Color.GRAY); setPadding(0, 30, 0, 0)
        })
        setContentView(root)
    }
}
